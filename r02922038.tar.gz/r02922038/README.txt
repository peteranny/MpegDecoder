R02922038

Type "make" to build executable file (under UNIX environment)

Type "make run IN=[input.m1v] OUT=[output_dir_name]" to decode mpeg files

Open play.htm and type in your output directory name to see the output.

